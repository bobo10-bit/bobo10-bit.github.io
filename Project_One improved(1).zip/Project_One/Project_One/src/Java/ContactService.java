package Java;
import java.util.Map;
import java.util.HashMap;

// Using hashmap to store contact information
public class ContactService {
	// changed to hashmap instead of array list.
	private Map<String, Contact> contacts = new HashMap<>();

    // Add contact if the ID is unique else throw an error
    public void addContact(Contact contact) {
    	if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Delete contact by ID
    public void deleteContact(String contactId) {
    	if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contacts.remove(contactId);
    }

    // Update first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = findContact(contactId);
        contact.setFirstName(firstName);
    }

    // Update last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = findContact(contactId);
        contact.setLastName(lastName);
    }

    // Update phone number
    public void updatePhone(String contactId, String phone) {
        Contact contact = findContact(contactId);
        contact.setPhone(phone);
    }

    // Update address
    public void updateAddress(String contactId, String address) {
        Contact contact = findContact(contactId);
        contact.setAddress(address);
    }

    // Helper method for contact lookup
    private Contact findContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        return contact;
    }
}