package Java;
import java.util.ArrayList;
import java.util.List;

// Using arraylist to store contact information
public class ContactService {
    private List<Contact> contacts = new ArrayList<>();

    // Add contact if the ID is unique else throw an error
    public void addContact(Contact contact) {
        for (Contact c : contacts) {
            if (c.getContactId().equals(contact.getContactId())) {
                throw new IllegalArgumentException("Contact ID already exists.");
            }
        }
        contacts.add(contact);
    }

    // Delete contact by ID
    public void deleteContact(String contactId) {
        Contact toRemove = findContact(contactId);
        contacts.remove(toRemove);
    }

    // Update first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = findContact(contactId);
        contact.setFirstName(firstName);
    }

    // Update last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = findContact(contactId);
        contact.setLastName(lastName);
    }

    // Update phone number
    public void updatePhone(String contactId, String phone) {
        Contact contact = findContact(contactId);
        contact.setPhone(phone);
    }

    // Update address
    public void updateAddress(String contactId, String address) {
        Contact contact = findContact(contactId);
        contact.setAddress(address);
    }

    // Helper method to find a contact by contact Id
    private Contact findContact(String contactId) {
        for (Contact contact : contacts) {
            if (contact.getContactId().equals(contactId)) {
                return contact;
            }
        }
        throw new IllegalArgumentException("Contact not found.");
    }
}