package Java;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
	// Test with values being correct
    @Test
    public void testValidTask() {
        Task Task = new Task("1234567890", "John Smith", "A cool task description");
        assertEquals("1234567890", Task.getTaskId());
    }
    // Tests for the TaskId being null
    @Test
    public void testInvalidTaskIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Task(null, "John Smith", "A cool task description");
        });
    }
    @Test
    // Tests for the TaskId being too long
    public void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1234567890000000000", "John Smith", "A cool task description");
        });
    }
    // Tests for the name being null
    @Test
    public void testInvalidnameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Task("1234567890", null, "A cool task description");
        });
    }
    // Tests for the name being too long
    @Test
    public void testInvalidnameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Task("1234567890", "John Smith The Ultimate Super Great", "A cool task description");
        });
    }
    // Tests for the description being null
    @Test
    public void testInvalidDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Task("0000000000", "John Smith", null);
        });
    }
    // Tests for the Description being too long
    @Test
    public void testInvalidDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Task("1234567890", "John Smith", "A cool task description that is very very very very very very very very very very very very very very very very very very very very very long.");
        });
    }
    
}