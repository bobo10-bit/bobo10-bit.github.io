package Java;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	// Test with values being correct
    @Test
    public void testValidContact() {
        Contact contact = new Contact("1234567890", "John", "Smith", "1234567890", "123 Main Street");
        assertEquals("1234567890", contact.getContactId());
    }
    @Test
    // Tests for the contactId being too long
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890000000000", "John", "Smith", "1234567890", "123 Main Street");
        });
    }
    // Tests for the contactId being null
    @Test
    public void testInvalidContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith", "1234567890", "123 Main Street");
        });
    }
    // Tests for the phone number being null
    @Test
    public void testInvalidPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Smith", null, "123 Main Street");
        });
    }
    // Tests for the phone number not being length of 10
    @Test
    public void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Smith", "123345678900000", "123 Main Street");
        });
    }
    // Tests for the first name being null
    @Test
    public void testInvalidFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "Smith", "1234567890", "123 Main Street");
        });
    }
    // Tests for the first name being too long
    @Test
    public void testInvalidFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "JohnathanerTheGreat", "Smith", "1234567890", "123 Main Street");
        });
    }
    // Tests for the last name being null
    @Test
    public void testInvalidLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", null, "1234567890", "123 Main Street");
        });
    }
    // Tests for the last name being too long
    @Test
    public void testInvalidLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "SmitherineTheSuper", "1234567890", "123 Main Street");
        });
    }
    // Tests for the address being too long
    @Test
    public void testInvalidAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "SmitherineTheSuper", "1234567890", "1234567890 Main Street Super long street x 100000");
        });
    }
    
    @Test
    public void testInvalidAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "SmitherineTheSuper", "1234567890", null);
        });
    }
}