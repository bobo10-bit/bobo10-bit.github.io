package com.example.cs360projecttwo;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory",
        foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "id",
                childColumns = "userId",
                onDelete = ForeignKey.CASCADE))
public class InventoryItem {

    @PrimaryKey(autoGenerate = true)
    public int id;

    private String itemName;
    private int quantity;
    private int userId;

    public InventoryItem(String itemName, int quantity, int userId) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.userId = userId;
    }

    public int getId() { return id; }
    public String getItemName() { return itemName; }
    public int getQuantity() { return quantity; }
    public int getUserId() { return userId; }

    public void setItemName(String itemName) { this.itemName = itemName; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setUserId(int userId) { this.userId = userId; }
}

