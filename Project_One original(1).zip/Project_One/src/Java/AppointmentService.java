package Java;
import java.util.ArrayList;
import java.util.List;

// Using arraylist to store Appointment information
public class AppointmentService {
    private List<Appointment> Appointments = new ArrayList<>();

    // Add Appointment if the ID is unique else throw an error
    public void addAppointment(Appointment Appointment) {
        for (Appointment t : Appointments) {
            if (t.getAppointmentId().equals(Appointment.getAppointmentId())) {
                throw new IllegalArgumentException("Appointment ID already exists.");
            }
        }
        Appointments.add(Appointment);
    }

    // Delete Appointment by ID
    public void deleteAppointment(String AppointmentId) {
        Appointment toRemove = findAppointment(AppointmentId);
        Appointments.remove(toRemove);
    }
    
    // Helper method to find a Appointment by Appointment Id
    private Appointment findAppointment(String AppointmentId) {
        for (Appointment Appointment : Appointments) {
            if (Appointment.getAppointmentId().equals(AppointmentId)) {
                return Appointment;
            }
        }
        throw new IllegalArgumentException("Appointment not found.");
    }
}