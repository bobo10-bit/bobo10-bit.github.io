package Java;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;
    private Task Task;

    // Set up a TaskService instance and add one Task before each test
    @BeforeEach
    public void setup() {
        service = new TaskService();
        Task = new Task("1234567890", "John Smith", "A cool task description");
        service.addTask(Task);
    }

    // Test adding a Task with a duplicate ID
    @Test
    public void testAddDuplicateTaskId() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(new Task("1234567890", "John Smith", "A cool task description"));
        });
    }

    // Test deleting a Task that is deleted
    @Test
    public void testDeleteTask() {
        service.deleteTask("1234567890");
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("1234567890");
        });
    }

    // Test to update the name
    @Test
    public void testUpdateName() {
        service.updateName("1234567890", "Bobo Smith");
        assertEquals("Bobo Smith", Task.getName());
    }

    // Test updating a Task that does not exist
    @Test
    public void testUpdateInvalidTask() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("0000000000", "Long long description");
        });
    }
}