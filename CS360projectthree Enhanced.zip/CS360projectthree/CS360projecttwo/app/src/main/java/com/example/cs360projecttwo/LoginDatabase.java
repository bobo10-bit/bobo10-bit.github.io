package com.example.cs360projecttwo;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Handles the apps user login database
@Database(entities = {User.class}, version = 1)
public abstract class LoginDatabase extends RoomDatabase {

    private static LoginDatabase instance;

    public abstract UserDao userDao();

    public static synchronized LoginDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            LoginDatabase.class, "login_database")
                    .allowMainThreadQueries() // For simplicity; use async in production
                    .build();
        }
        return instance;
    }
}
