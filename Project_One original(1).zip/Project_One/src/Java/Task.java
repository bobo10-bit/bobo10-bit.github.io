package Java;

public class Task {

	// Variables for task
	private final String taskId;
	private String name;
	private String description;

	public Task(String taskId, String name, String description) {
		// Throws an error is the taskId is null or the length is over 10
		if (taskId == null || taskId.length() > 10)
			throw new IllegalArgumentException("Invalid task ID");
		// Throws an error is the name is null or the length is over 10
		if (name == null || name.length() > 20)
			throw new IllegalArgumentException("Invalid name");
		// Throws an error is the description is null or the length is over 30
		if (description == null || description.length() > 50)
			throw new IllegalArgumentException("Invalid description");

		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}

	// Getter methods
	public String getTaskId() {
		return taskId;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	// Setter methods
	public void setName(String name) {
		if (name == null || name.length() > 10)
			throw new IllegalArgumentException("Invalid name name");
		this.name = name;
	}

	public void setDescription(String description) {
		if (description == null || description.length() > 30)
			throw new IllegalArgumentException("Invalid description");
		this.description = description;
	}
}