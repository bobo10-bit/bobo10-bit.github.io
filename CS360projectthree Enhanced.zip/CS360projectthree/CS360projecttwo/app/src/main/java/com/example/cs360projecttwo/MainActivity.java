package com.example.cs360projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;
    private InventoryDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loggin);

        db = InventoryDatabase.getInstance(this);

        // Use IDs from your XML
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login);
        createAccountButton = findViewById(R.id.createAccount);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> registerUser());
    }

    // Checks username and password for loggin in
    private void loginUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = db.userDao().getUser(username, password);
        if (user != null) {
            // Save user ID in SharedPreferences
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putInt("LOGGED_IN_USER_ID", user.id)
                    .apply();

            Intent intent = new Intent(this, ActivityInventory.class);
            intent.putExtra("USER_ID", user.id);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Creates a new user account in the database
    private void registerUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User(username, password);
        db.userDao().insert(user);

        Toast.makeText(this, "Profile created! You can now log in.", Toast.LENGTH_SHORT).show();
    }
}