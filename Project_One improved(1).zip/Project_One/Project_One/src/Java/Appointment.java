package Java;
import java.util.Date;
public class Appointment {

	// Variables for Appointment
	private final String appointmentId;
	private Date appointmentDate;
	private String description;

	public Appointment(String appointmentId, Date appointmentDate, String description) {
		// Throws an error is the appointmentId is null or the length is over 10
		if (appointmentId == null || appointmentId.length() > 10)
			throw new IllegalArgumentException("Invalid Appointment ID");
		// Throws an error is the appointmentDate is null or the length is before current date
		if (appointmentDate == null || appointmentDate.before(new Date()))
			throw new IllegalArgumentException("Invalid appointmentDate");
		// Throws an error is the description is null or the length is over 50
		if (description == null || description.length() > 50)
			throw new IllegalArgumentException("Invalid description");

		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}

	// Getter methods
	public String getAppointmentId() {
		return appointmentId;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public String getDescription() {
		return description;
	}

	// Setter methods
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null || appointmentDate.before(new Date()))
			throw new IllegalArgumentException("Invalid appointmentDate appointmentDate");
		this.appointmentDate = appointmentDate;
	}

	public void setDescription(String description) {
		if (description == null || description.length() > 50)
			throw new IllegalArgumentException("Invalid description");
		this.description = description;
	}
}