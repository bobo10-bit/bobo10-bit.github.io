package com.example.cs360projecttwo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ActivityInventory extends AppCompatActivity {

    private InventoryDatabase db;
    private TableLayout tableLayout;
    private EditText editTextItem, editTextQuantity;
    private InventoryItem selectedItem = null;
    private int currentUserId;
    private static final String CHANNEL_ID = "inventory_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = InventoryDatabase.getInstance(this);

        // Load logged-in user ID from SharedPreferences
        currentUserId = getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getInt("LOGGED_IN_USER_ID", -1);
        if (currentUserId == -1) {
            Toast.makeText(this, "No user logged in! Please log in.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tableLayout = findViewById(R.id.tableLayout);
        editTextItem = findViewById(R.id.editTextItem);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        FloatingActionButton addButton = findViewById(R.id.floatingActionButton2);

        // Numeric-only input for quantity with inline error
        editTextQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString();
                if (!input.matches("\\d*")) {
                    editTextQuantity.setError("Only numbers allowed");
                    String clean = input.replaceAll("[^\\d]", "");
                    editTextQuantity.setText(clean);
                    editTextQuantity.setSelection(clean.length());
                }
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });

        addButton.setOnClickListener(v -> addItem());

        loadTable(currentUserId); // <-- load inventory for this user only

        // Bottom Navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.nav_inventory);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_inventory) return true;
            if (itemId == R.id.nav_settings) {
                startActivity(new Intent(ActivityInventory.this, SettingsActivity.class));
                return true;
            }
            return false;
        });

        createNotificationChannel();
    }

    @SuppressLint("SetTextI18n")
    private void loadTable(int userId) {
        tableLayout.removeViews(1, tableLayout.getChildCount() - 1); // keep header

        List<InventoryItem> items = db.inventoryDao().getItemsForUser(userId);

        for (InventoryItem item : items) {
            TableRow row = new TableRow(this);

            TableRow.LayoutParams params = new TableRow.LayoutParams(0,
                    TableRow.LayoutParams.WRAP_CONTENT, 1);

            EditText nameField = new EditText(this);
            nameField.setText(item.getItemName());
            nameField.setSingleLine(true);
            nameField.setPadding(16,16,16,16);
            nameField.setLayoutParams(params);

            EditText quantityField = new EditText(this);
            quantityField.setText(String.valueOf(item.getQuantity()));
            quantityField.setSingleLine(true);
            quantityField.setPadding(16,16,16,16);
            quantityField.setInputType(InputType.TYPE_CLASS_NUMBER);
            quantityField.setLayoutParams(params);

            // TextWatcher for inline error while editing table rows
            quantityField.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    String input = s.toString();
                    if (!input.matches("\\d*")) {
                        quantityField.setError("Only numbers allowed");
                        String clean = input.replaceAll("[^\\d]", "");
                        quantityField.setText(clean);
                        quantityField.setSelection(clean.length());
                    }
                }

                @Override
                public void afterTextChanged(Editable s) { }
            });

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setBackgroundColor(0xFFFF1300);
            deleteButton.setTextColor(0xFFFFFFFF);

            deleteButton.setOnClickListener(v -> {
                db.inventoryDao().delete(item);
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                loadTable(currentUserId);
            });

            nameField.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    String newName = nameField.getText().toString().trim();
                    if (!newName.equals(item.getItemName())) {
                        item.setItemName(newName);
                        db.inventoryDao().update(item);
                        Toast.makeText(this, "Item name updated", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            quantityField.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    String newQtyStr = quantityField.getText().toString().trim();
                    if (!newQtyStr.isEmpty()) {
                        try {
                            int newQty = Integer.parseInt(newQtyStr);
                            if (newQty != item.getQuantity()) {
                                item.setQuantity(newQty);
                                db.inventoryDao().update(item);
                                Toast.makeText(this, "Quantity updated", Toast.LENGTH_SHORT).show();
                            }
                        } catch (NumberFormatException e) {
                            quantityField.setError("Enter a valid integer");
                        }
                    }
                }
            });

            row.addView(nameField);
            row.addView(quantityField);
            row.addView(deleteButton);

            tableLayout.addView(row);

            // Low stock notification
            if (item.getQuantity() <= 1) sendLowStockNotification(item.getItemName());
        }
    }

    private void addItem() {
        String name = editTextItem.getText().toString().trim();
        String quantityStr = editTextQuantity.getText().toString().trim();

        if (name.isEmpty() || quantityStr.isEmpty()) {
            Toast.makeText(this, "Enter both item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            editTextQuantity.setError("Enter a valid integer");
            return;
        }

        InventoryItem item = new InventoryItem(name, quantity, currentUserId);
        db.inventoryDao().insert(item);

        Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
        editTextItem.setText("");
        editTextQuantity.setText("");
        loadTable(currentUserId);
    }

    // ---------------- Notifications ----------------
    private void createNotificationChannel() {
        CharSequence name = "Inventory Alerts";
        String description = "Notifications for low stock items";
        int importance = NotificationManager.IMPORTANCE_DEFAULT;

        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private void sendLowStockNotification(String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Low Stock Alert")
                .setContentText(itemName + " has 1 or less in stock!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.notify(itemName.hashCode(), builder.build());
    }
}