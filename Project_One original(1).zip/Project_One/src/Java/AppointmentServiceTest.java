package Java;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment Appointment;
    

    // Set up a AppointmentService instance and add one Appointment before each test
    @BeforeEach
    public void setup() throws ParseException {
        service = new AppointmentService();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        Appointment = new Appointment("1234567890", appointmentDate , "A cool Appointment description");
        service.addAppointment(Appointment);
    }

    // Test adding a Appointment with a duplicate ID
    @Test
    public void testAddDuplicateAppointmentId() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(new Appointment("1234567890", appointmentDate, "A cool Appointment description"));
        });
    }

    // Test deleting a Appointment that is deleted
    @Test
    public void testDeleteAppointment() {
        service.deleteAppointment("1234567890");
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("1234567890");
        });
    }
}