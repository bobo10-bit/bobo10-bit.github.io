package Java;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    // Set up a ContactService instance and add one contact before each test
    @BeforeEach
    public void setup() {
        service = new ContactService();
        contact = new Contact("001", "Bob", "Bobo", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    // Test adding a contact with a duplicate ID
    @Test
    public void testAddDuplicateContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(new Contact("001", "John", "Smith", "0987654321", "321 Blvd"));
        });
    }

    // Test deleting a contact and then trying to delete again 
    @Test
    public void testDeleteContact() {
        service.deleteContact("001");
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("001");
        });
    }

    // Test to update the first name
    @Test
    public void testUpdateFirstName() {
        service.updateFirstName("001", "Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    // Test updating a contact that does not exist
    @Test
    public void testUpdateInvalidContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("999", "1112223333");
        });
    }
}