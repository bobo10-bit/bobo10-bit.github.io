package com.example.cs360projecttwo;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// Manages the apps inventory and user data
@Database(entities = {InventoryItem.class, User.class}, version = 2)
public abstract class InventoryDatabase extends RoomDatabase {

    private static InventoryDatabase instance;

    public abstract InventoryDao inventoryDao();
    public abstract UserDao userDao();  // <-- add this

    public static synchronized InventoryDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            InventoryDatabase.class, "inventory_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries() // optional, for simplicity
                    .build();
        }
        return instance;
    }
}
