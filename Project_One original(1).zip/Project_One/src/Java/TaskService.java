package Java;
import java.util.ArrayList;
import java.util.List;

// Using arraylist to store task information
public class TaskService {
    private List<Task> tasks = new ArrayList<>();

    // Add task if the ID is unique else throw an error
    public void addTask(Task task) {
        for (Task t : tasks) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("task ID already exists.");
            }
        }
        tasks.add(task);
    }

    // Delete task by ID
    public void deleteTask(String taskId) {
        Task toRemove = findtask(taskId);
        tasks.remove(toRemove);
    }

    // Update name
    public void updateName(String taskId, String name) {
        Task task = findtask(taskId);
        task.setName(name);
    }

    // Update description 
    public void updateDescription(String taskId, String description) {
        Task task = findtask(taskId);
        task.setDescription(description);
    }

    // Helper method to find a task by task Id
    private Task findtask(String taskId) {
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                return task;
            }
        }
        throw new IllegalArgumentException("task not found.");
    }
}