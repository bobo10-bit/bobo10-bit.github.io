package Java;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {
	// Test with values being correct
    @Test
    public void testValidAppointment() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        Appointment Appointment = new Appointment("1234567890", appointmentDate, "A cool Appointment description");
        assertEquals("1234567890", Appointment.getAppointmentId());
    }
    // Tests for the AppointmentId being null
    @Test
    public void testInvalidAppointmentIdNull() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(null, appointmentDate, "A cool Appointment description");
        });
    }
    @Test
    // Tests for the AppointmentId being too long
    public void testInvalidAppointmentId() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890000000000", appointmentDate, "A cool Appointment description");
        });
    }
    // Tests for the date being null
    @Test
    public void testInvalidDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment("1234567890", null, "A cool Appointment description");
        });
    }
    // Tests for the date being in the past
    @Test
    public void testInvalidDatePast() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2000-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment("1234567890", appointmentDate, "A cool Appointment description");
        });
    }
    // Tests for the description being null
    @Test
    public void testInvalidDescriptionNull() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment("0000000000", appointmentDate, null);
        });
    }
    // Tests for the Description being too long
    @Test
    public void testInvalidDescriptionTooLong() throws ParseException {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date appointmentDate = sdf.parse("2025-12-31 00:00:00");
        assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment("1234567890", appointmentDate, "A cool Appointment description that is very very very very very very very very very very very very very very very very very very very very very long.");
        });
    }
    
}